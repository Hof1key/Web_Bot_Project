import json

import vk_api
from vk_api.keyboard import VkKeyboardColor, VkKeyboard
from vk_api.longpoll import VkLongPoll, VkEventType
import random


def write_msg(chat_id, message):
    rnd_id = random.randint(0, 2 ** 64)
    vk.method('messages.send', {'chat_id': chat_id,
                                'message': message,
                                'random_id': rnd_id})


def write_message(user_id, message, keyboard=json.dumps({"buttons": [], "one_time": True})):
    vk_api = vk.get_api()

    vk_api.messages.send(user_id=user_id,
                         message=message,
                         keyboard=keyboard,
                         random_id=random.randint(0, 2 ** 64))

def statistics(database, user_id, row, value):
    pass


'''def create_keyboard(response):
    keyboard = VkKeyboard(one_time=True)

    if response == 'привет':
        keyboard.add_button('Хочу тян', color=VkKeyboardColor.POSITIVE)
        keyboard.add_button('Тян не нужны', color=VkKeyboardColor.NEGATIVE)

    elif response == 'какой у меня выбор?':
        keyboard.add_button('Хочу тян', color=VkKeyboardColor.POSITIVE)
        keyboard.add_button('Тян не нужны', color=VkKeyboardColor.NEGATIVE)

    elif response == 'выбор?':
        keyboard.add_button('Хочу тян', color=VkKeyboardColor.POSITIVE)
        keyboard.add_button('Тян не нужны', color=VkKeyboardColor.NEGATIVE)
    else:
        keyboard.add_button('Хочу тян', color=VkKeyboardColor.POSITIVE)
        keyboard.add_button('Тян не нужны', color=VkKeyboardColor.NEGATIVE)

    keyboard = keyboard.get_keyboard()
    return keyboard'''


# API-ключ созданный ранее
token = "455abef9e5a275893cf3edf18701cc8f77b92896c0803aafc210fc1a58d2393f96916a58df187fbf21bc1"

# Авторизуемся как сообщество
vk = vk_api.VkApi(token=token)

# Работа с сообщениями
longpoll = VkLongPoll(vk)

# Основной цикл
for event in longpoll.listen():

    # Если пришло новое сообщение
    '''if event.type == VkEventType.MESSAGE_NEW:


        # Если оно имеет метку для меня( то есть бота)
        if event.to_me:

            if event.from_chat:

                txt = event.text

                print(txt + '1')

                write_msg(event.chat_id, txt)


        if event.from_user:

            txt = event.text

            print(txt + '2')

            write_msg(event.user_id, txt)'''

    if event.type == VkEventType.MESSAGE_NEW:

        if event.from_chat:

            if not event.to_me:
                continue

            txt = str(event.text)

            if txt.startswith('!'):

                cmd = txt[1:].split(' ')

                if cmd[0] in ['kick', 'кик', 'ban', 'бан']:

                    id = cmd[1]

                    if id[:2] == 'id':
                        id = id[2:]

                    vk_api = vk.get_api()

                    try:
                        ans = vk_api.messages.removeChatUser(chat_id=event.chat_id,
                                                             member_id=id)
                    except Exception as ex:
                        ans = ex

                    if ans == 1:

                        user_from = event.user_id
                        write_msg(chat_id=event.chat_id,
                                  message='Пользователь успешно выгнан из беседы!')

                    else:
                        write_msg(chat_id=event.chat_id,
                                  message=ans)

            user = event.from_user

            # write_msg(event.chat_id, txt)

        elif event.from_user:

            if not event.to_me:
                continue

            txt = event.text.lower()

            # keyboard = create_keyboard(txt)

            vk_api = vk.get_api()

            if txt == "да":

                write_message(user_id=event.user_id,
                              message='Число загадано.')

                write_message(user_id=event.user_id,
                              message='Выберите, ЧЕТНОЕ оно или НЕЧЕТНОЕ?',
                              keyboard=open("game.json", "r",
                                            encoding="UTF-8").read())

            elif txt == 'нет':

                write_message(
                    user_id=event.user_id,
                    message='Ну и пошёл отсюда!!!')

            elif txt == 'вернуться назад':

                write_message(user_id=event.user_id,
                              message='Оставили вас без игры')

            else:

                write_message(user_id=event.user_id,
                              message='Сыграем в Чет/Нечет?',
                              keyboard=open("keyboard.json", "r",
                                            encoding="UTF-8").read())

            '''write_message(user_id=event.user_id,
                                 message='Спасибо, что написали нам. Ваше сообщение передано администрации.')
'''
